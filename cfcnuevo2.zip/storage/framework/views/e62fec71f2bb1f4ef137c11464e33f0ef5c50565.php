<div class="modal fade" id="tratamientoedit<?php echo e($list->tra_id); ?>" data-backdrop="static" data-keyboard="false" tabindex="-1"
    aria-labelledby="servicio-nuevoLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="servicio-nuevoLabel">Actualizar Tratamiento</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="<?php echo e(route('tratamiento.update', $list->tra_id)); ?>" method="POST" name="tratamiento">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="modal-body">

                    <div class="form-group">
                        <label for="ser_id">Seleccionar Servicio</label>
                        <select class="form-control" id="ser_id" name="ser_id">
                            <option value="<?php echo e($list->ser_id); ?>" selected><?php echo e($list->ser_nombres); ?></option>
                            <option value="" disabled>-- Escoja su servicio--</option>
                            <?php $__currentLoopData = $servicio; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($list2->ser_id); ?>"><?php echo e($list2->ser_nombres); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="tit_id">Seleccionar Tipo</label>
                        <select class="form-control" id="tit_id" name="tit_id">
                            <option value="<?php echo e($list->tit_id); ?>" selected><?php echo e($list->tit_nombres); ?></option>
                            <option value="" disabled>-- Escoja su tipo de tratamiento--</option>
                            <?php $__currentLoopData = $tipos_tratamientos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list3): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($list3->tit_id); ?>"><?php echo e($list3->tit_nombres); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="tra_nombres">Tratamiento:</label>
                        <input type="text" class="form-control" value="<?php echo e($list->tra_nombres); ?>" id="tra_nombres"
                            name="tra_nombres" rows="3">
                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-sm btn-secondary" data-dismiss="modal"><i
                            class="fas fa-times mr-1"></i>Cancelar</button>
                    <button type="submit" class="btn btn-sm btn-primary"><i class="fas fa-save mr-1"></i>Guardar</button>
                </div>
            </form>
        </div>
    </div>
</div>




<form action="<?php echo e(url('/servicios/enviar')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="modal fade" id="serviciocreate" data-backdrop="static" data-keyboard="false" tabindex="-1"
      aria-labelledby="doctor-nuevoLabel" aria-hidden="true">
      <div class="modal-dialog">
          <div class="modal-content">
              <div class="modal-header">
                  <h5 class="modal-title" id="doctor-nuevoLabel">Nuevo Servicio</h5>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                  </button>
              </div>
              <div class="modal-body">

                    <div class="form-group">
                        <label for="ser_id">Seleccionar Servicio</label>
                        <select class="form-control" id="ser_id" name="ser_id">
                            <option value="<?php echo e($list->ser_id); ?>" selected><?php echo e($list->ser_nombres); ?></option>
                            <option value="" disabled>-- Escoja su servicio--</option>
                            <?php $__currentLoopData = $servicio; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($list2->ser_id); ?>"><?php echo e($list2->ser_nombres); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="tit_id">Seleccionar Tipo</label>
                        <select class="form-control" id="tit_id" name="tit_id">
                            <option value="<?php echo e($list->tit_id); ?>" selected><?php echo e($list->tit_nombres); ?></option>
                            <option value="" disabled>-- Escoja su tipo de tratamiento--</option>
                            <?php $__currentLoopData = $tipos_tratamientos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list3): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($list3->tit_id); ?>"><?php echo e($list3->tit_nombres); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="tra_nombres">Tratamiento:</label>
                        <input type="text" class="form-control" value="<?php echo e($list->tra_nombres); ?>" id="tra_nombres"
                            name="tra_nombres" rows="3">
                    </div>

                </div>
              <div class="modal-footer">
                  <button type="button" class="btn btn-sm btn-secondary" data-dismiss="modal"><i
                          class="fas fa-times mr-1"></i>Cancelar</button>
                  <button type="submit" class="btn btn-sm btn-primary"><i class="fas fa-save mr-1"></i>Guardar</button>
              </div>
          </div>
      </div>
   </div>
  </form>
  <?php /**PATH C:\Users\USER\Desktop\otro\cfcnuevo2\resources\views/modal/tratamientoedit.blade.php ENDPATH**/ ?>