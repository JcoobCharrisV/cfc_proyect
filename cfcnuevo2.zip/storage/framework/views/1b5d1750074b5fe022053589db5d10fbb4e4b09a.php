<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
</head>

<body>

    <div class="container-fluid px-5">
       
            <div class="col-12">
                <div class="table-responsive">
                    <table class="table table-bordered" style="border-color: rgb(0,112,192);">
                        <thead>
                            <tr>
                                <th class=" text-center" style="width:250px ;" scope="col"
                                    rowspan="2"><img src="/img/favicon.png"></th>
                                <th class="text-center" scope="col" style="color: rgb(0,112,192);">
                                    <h1>CHECKLIST FASE<br> HIGIÉNICA</h1> <br> FECHA DE ATENCION: 10/12/2022
                                </th>
                                <th class=" text-center" style="width:250px ;" scope="col"
                                    rowspan="2"><img src="/img/favicon.png" alt=""></th>
                            </tr>
                        </thead>
                    </table>
                </div>
            </div>
            <div class="col-12">
                <table class="table table-bordered" style="border-color: rgb(0,112,192);">
                    <tbody>
                      <tr>
                        <td colspan="2"><h5>NOMBRE PACIENTE: JORGE ANTONIO CACERES MARZOLA</h5></td>
                      </tr>
                      <tr>
                        <td><h5>IDENTIFICACIÓN: CC - 1143159076</h5></td>
                        <td><h5>TELÉFONO CELULAR: 3043668820</h5></td>
                      </tr>
                      <tr>
                        <td><h5>EDAD: 26 AÑOS - 18/10/1996</h5></td>
                        <td><h5>DOCTOR: ROBERTO ARCON</h5></td>
                      </tr>
                      <tr>
                        <td colspan="2"><h5>CORREO ELECTRÓNICO: JORKCACERES@GMAIL.COM</h5></td>
                      </tr>
                      <tr>
                        <td><h5>SERVICIO: BLANQUEAMIENTO DENTAL</h5></td>
                        <td><h5>PRÓXIMA ATENCIÓN: 25/02/2022 14:30</h5></td>
                      </tr>

                    </tbody>
                  </table>
         
            </div>

            <div class="col-12">
                <table>
                    <thead>
                        <div class="table-responsive" id="formato-checklist">
                            <table class="table table-bordered table-sm checklist-tabla" width="100%" cellspacing="0">
                                <thead style="background-color:  rgb(0,112,192); color: #ffff;" >
                                    <tr>
                                        <th class="text-center" rowspan="2" style="vertical-align:middle;"><h2>TAREA</h2></th>
                                        <th class="text-center" colspan="2">EFECTIVO</th>
                                        <th class="text-center" rowspan="2" style="vertical-align:middle;"><h2>OBSERVACIONES</h2></th>
                                    </tr>
                                    <tr>
                                        <th class="text-center">SI</th>
                                        <th class="text-center">NO</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td style="text-align: left;">Fotos Intraorales del paciente</td>
                                        <td>
                                            <div class="form-check">
                                                <input class="form-check-input" type="radio" name="pregunta-1"
                                                    id="1" value="1">
                                            </div>
                                        </td>
                                        <td>
                                            <div class="form-check">
                                                <input class="form-check-input" type="radio" name="pregunta-1"
                                                    id="2" value="2">
                                            </div>
                                        </td>
                                        <td>
                                            <textarea class="form-control" id="pregunta-1" rows="2"></textarea>
                                        </td>
                                    </tr>
                                </tbody>
                        </div>
                    </thead>
                </table>
            </div>

            <div class="col-12">
                <div class="table-responsive" id="formato-checklist">
                    <table class="table table-bordered table-sm checklist-tabla" width="100%" cellspacing="0">
                        <tr style="background-color:  rgb(0,112,192); color: #ffff;">
                            <td class="border"style="text-align: center;"><h2>OBSERVACIONES</h2></td>
                        </tr>
                        <tr>
                            <td>
                                <input class="form-control" id="pregunta-1" rows="2">
                            </td>
                        </tr>
                    </table>
                </div>
            </div>
    </div>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous">
    </script>
</body>

</html>
<?php /**PATH C:\Users\USER\Desktop\CFC\Nueva carpeta\cfcnuevo\resources\views/pdfgestion.blade.php ENDPATH**/ ?>