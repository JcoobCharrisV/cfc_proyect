<div class="modal fade" id="cfc-nuevo" data-backdrop="static" data-keyboard="false" tabindex="-1"
    aria-labelledby="cfc-nuevoLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="cfc-nuevoLabel">Agrupar Doctor & Servicio</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="<?php echo e(url('/cfc/enviar')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="doc_id">Seleccionar Doctor</label>
                        <a data-toggle="tooltip" data-placement="top" title="">
                        </a>
                        <select multiple class="form-control" id="doc_id" name="doc_id[]" required>
                            <?php $__currentLoopData = $doctores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($list->doc_id); ?>"><?php echo e($list->doc_nombres); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="stt_id">Seleccionar Servicio</label>
                        <select class="form-control" name="stt_id" id="stt_id" required>
                            <?php $__currentLoopData = $tratamiento; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($list->tra_id); ?>" ><?php echo e($list->tra_nombre); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
            </div>
            
            <div class="modal-footer">
                <button type="button" class="btn btn-sm btn-secondary" data-dismiss="modal"><i
                        class="fas fa-times mr-1"></i>Cancelar</button>
                <button type="submit" class="btn btn-sm btn-primary"><i class="fas fa-save mr-1"></i>Guardar</button>
            </div>
            </form>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\USER\Desktop\otro\cfcnuevo2\resources\views/modal/cfc-nuevo.blade.php ENDPATH**/ ?>