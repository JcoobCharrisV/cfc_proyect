<!DOCTYPE html>
<html lang="es">

<head>

    <?php echo $__env->make("layouts.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>Perfil Paciente - Programa de Mantenimiento</title>

</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
            <?php echo $__env->make("layouts.sidebar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                    <?php echo $__env->make("layouts.topbar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                   
                        <?php echo $__env->make("modal.paciente-mantenimiento-nuevo", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
                        <?php echo $__env->make("modal.paciente-mantenimiento-ver", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
                        <?php echo $__env->make("modal.paciente-mantenimiento-editar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
                        <?php echo $__env->make("modal.paciente-mantenimiento-mensaje", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
                        <?php echo $__env->make("modal.paciente-mantenimiento-eliminar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
                        

                        <?php echo $__env->make("modal.paciente-contactabilidad-editar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
                        <?php echo $__env->make("modal.paciente-contactabilidad-eliminar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Perfil del Paciente</h1>
                        <div>
                            <a href="/home" type="button" class="btn btn-secondary btn-sm"><i class="fas fa-times mr-1"></i>Cerrar</a>
                            <div class="btn-group" role="group">
                                <button type="button" class="btn btn-primary btn-sm dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                                    <i class="fas fa-bars mr-1"></i>Opciones
                                </button>
                                <div class="dropdown-menu">
                                    <div class="dropdown-header">Nuevo:</div>
                                    <a type="button" data-toggle="modal" data-target="#paciente-mantenimiento-nuevo" class="dropdown-item"><i class="fas fa-fw fa-calendar-alt mr-1"></i>Mantenimiento</a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Content Row -->
                    <div class="alert alert-info" role="alert">

                        <div class="row text-center">
                            <div class="col-md-12 mb-2">
                                <h2>Jorge Antonio Cáceres Marzola</h2>
                            </div>
                        </div>
                        <div class="row text-center">
                            <div class="col-md-4">
                                <h6><strong>Identificación:</strong> CC - 1143159076</h6>
                                <h6><strong>Edad:</strong> 26 Años - 18/10/1996</h6>
                            </div>
                            <div class="col-md-4">
                                <h6><strong>Teléfono Celular:</strong> 3043668820</h6>
                                <h6><strong>Correo Electrónico:</strong> jorkcaceres@gmail.com</h6>
                            </div>
                            <div class="col-md-4">
                                <h6><strong>País de Origen:</strong> Colombia</h6>
                                <h6><strong>País de Residencia:</strong> Estados Unidos</h6>
                            </div>
                        </div>

                    </div>

                    

                    <div class="row">

                        <!-- Tabla -->
                        <div class="col-xl-12 col-lg-12">
                            <div class="card shadow mb-4">
                                <!-- Card Header - Dropdown -->
                                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                    <h6 class="m-0 font-weight-bold text-primary">Gestión de Mantenimientos</h6>
                                </div>
                                <!-- Card Body -->
                                <div class="card-body">

                                    <div class="table-responsive">
                                        <table class="table table-bordered table-sm" id="MantenimeintoListar" width="100%" cellspacing="0">
                                            <thead class="bg-gray-200">
                                                <tr>
                                                    <th>Código</th>
                                                    <th>Fecha Atención</th>
                                                    <th>Servicio</th>
                                                    <th>Frecuencia</th>
                                                    <th>Próxima Atención</th>
                                                    <th>Acciones</th>
                                                </tr>
                                            </thead>
                                            <tfoot class="bg-gray-200">
                                                <tr>
                                                    <th>Código</th>
                                                    <th>Fecha Atención</th>
                                                    <th>Servicio</th>
                                                    <th>Frecuencia</th>
                                                    <th>Próxima Atención</th>
                                                    <th>Acciones</th>
                                                </tr>
                                            </tfoot>
                                            <tbody>
                                                <tr>
                                                    <td>01</td>
                                                    <td>24/11/2022 14:30</td>
                                                    <td>Blanqueamiento Dental</td>
                                                    <td>3 Meses</td>
                                                    <td>25/02/2022 14:30</td>
                                                    <td>
                                                        <a type="button" data-toggle="modal" data-target="#paciente-mantenimiento-ver" class="btn btn-primary btn-circle btn-sm"><i class="fas fa-eye fa-sm"></i></a>
                                                        <a type="button" data-toggle="modal" data-target="#paciente-mantenimiento-editar" class="btn btn-secondary btn-circle btn-sm"><i class="fas fa-pencil-alt fa-sm"></i></a>
                                                        <a type="button" data-toggle="modal" data-target="#paciente-mantenimiento-mensaje" class="btn btn-warning btn-circle btn-sm"><i class="fas fa-envelope fa-sm"></i></a>
                                                        <a type="button" data-toggle="modal" data-target="#paciente-mantenimiento-eliminar" class="btn btn-danger btn-circle btn-sm"><i class="fas fa-trash fa-sm"></i></a>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>

                    </div>

                    <div class="row">

                        <!-- Tabla -->
                        <div class="col-xl-12 col-lg-12">
                            <div class="card shadow mb-4">
                                <!-- Card Header - Dropdown -->
                                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                    <h6 class="m-0 font-weight-bold text-primary">Gestión de Contactabilidad</h6>
                                </div>
                                <!-- Card Body -->
                                <div class="card-body">

                                    <div class="table-responsive">
                                        <table class="table table-bordered table-sm" id="ContactabilidadListar" width="100%" cellspacing="0">
                                            <thead class="bg-gray-200">
                                                <tr>
                                                    <th>Código</th>
                                                    <th>Fecha Gestión</th>
                                                    <th>Tipificación</th>
                                                    <th>Observación</th>
                                                    <th>Acciones</th>
                                                </tr>
                                            </thead>
                                            <tfoot class="bg-gray-200">
                                                <tr>
                                                    <th>Código</th>
                                                    <th>Fecha Gestión</th>
                                                    <th>Tipificación</th>
                                                    <th>Observación</th>
                                                    <th>Acciones</th>
                                                </tr>
                                            </tfoot>
                                            <tbody>
                                                <tr>
                                                    <td>01</td>
                                                    <td>23/10/2022 15:15</td>
                                                    <td>Buzón de Voz</td>
                                                    <td>El paciente no contesta, se realizaron 3 marcaciones</td>
                                                    <td>
                                                        <a type="button" data-toggle="modal" data-target="#paciente-contactabilidad-editar" class="btn btn-secondary btn-circle btn-sm"><i class="fas fa-pencil-alt fa-sm"></i></a>
                                                        <a type="button" data-toggle="modal" data-target="#paciente-contactabilidad-eliminar" class="btn btn-danger btn-circle btn-sm"><i class="fas fa-trash fa-sm"></i></a>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>

                    </div>

                    

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
                 <?php echo $__env->make("layouts.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

</body>

</html><?php /**PATH C:\Users\USER\Desktop\CFC\Nueva carpeta\cfcnuevo\resources\views/paciente\pacienteperfil.blade.php ENDPATH**/ ?>