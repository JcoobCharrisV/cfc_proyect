<div class="modal fade" id="paciente-mantenimiento-mensaje" data-backdrop="static" data-keyboard="false" tabindex="-1" role="dialog" aria-labelledby="paciente-mantenimiento-mensajeLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="paciente-mantenimiento-mensajeLabel">Notificar Mantenimiento</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">Seleccione "Enviar" si está seguro de enviar la información registrada en el sistema.</div>
            <div class="modal-footer">
              <button class="btn btn-sm btn-secondary" type="button" data-dismiss="modal"><i class="fas fa-times mr-1"></i>Cancelar</button>
              <a class="btn btn-sm btn-primary"><i class="fas fa-paper-plane mr-1"></i>Enviar</a>
            </div>
        </div>
    </div>
</div>